from django.db import models

class Course(models.Model):
    name=models.CharField(max_length=20,null=False)
    description=models.CharField(max_length=200,null=True)
    thumbnail=models.ImageField(upload_to="files/thumbnail")
    date=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.name
    def get_thumbnail_url(self):
        print(self.thumbnail.url)
        return self.thumbnail.url
class Modules(models.Model):
    name=models.CharField(max_length=20,null=False)
    description=models.CharField(max_length=200,null=True)
    course=models.ForeignKey(Course,null=False,related_name="course_name",on_delete=models.CASCADE)
    


