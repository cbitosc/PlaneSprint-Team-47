from django.contrib import admin
from technifyme.models import Course,Modules

class ModuleAdmin(admin.TabularInline):
    model=Modules
class CourseAdmin(admin.ModelAdmin):
    inlines=[ModuleAdmin]
admin.site.register(Course,CourseAdmin)